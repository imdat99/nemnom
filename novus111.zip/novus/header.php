<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package novus
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<main id="page"
	class="site"
	x-data="{ hideBar: false }"
	>
	<header id="masthead"
		class="site-header"
		:class="{ 'hidden' : hideBar }"
		@scroll.window="hideBar = (window.pageYOffset > 50) ? true : false"
		>
		<div class="container">
			<?= the_custom_logo(); ?>

			<?php wp_nav_menu( 'menu_1' ); ?>

			<?php get_template_part( 'template-parts/social' ) ?>
		</div>
	</header>