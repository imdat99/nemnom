<?php
/**
 * Template Name: Contact
 */
get_header();

get_template_part( 'template-parts/banner' );

get_template_part( 'template-parts/feedback' );

get_footer();