<?php
/**
 * Template Name: Menu
 */
get_header();

get_template_part( 'template-parts/banner' );
get_template_part( 'template-parts/menu/menu' );
get_template_part( 'template-parts/home/reservation' );


get_footer();