<?php
/**
 * Template Name: Gallery
 */
get_header();

get_template_part( 'template-parts/banner' );
get_template_part( 'template-parts/gallery/gallery' );


get_footer();