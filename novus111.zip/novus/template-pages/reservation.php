<?php
/**
 * Template Name: Reservation
 */
get_header();

get_template_part( 'template-parts/banner' );
get_template_part( 'template-parts/home/reservation' );



get_footer();