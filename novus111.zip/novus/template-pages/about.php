<?php
/**
 * Template name: About
 */
get_header();

get_template_part( 'template-parts/banner' );
get_template_part( 'template-parts/about/intro' );
get_template_part( 'template-parts/home/testimonials' );

get_footer();