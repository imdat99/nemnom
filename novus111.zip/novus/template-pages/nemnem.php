<?php

/**
 * Template Name: Menu NemNme
 */
get_header();
// $uri = get_template_directory_uri() . "/menu/nemnem.json";
// $string = file_get_contents($uri);
// var_dump($uri);
?>

<head>
    <script type="module" src="http://localhost:5173/@vite/client"></script>
</head>
<div id="app"></div>
<script type="module" src="http://localhost:5173/src/main.ts"></script>
<!-- <script type="module" src="<?= NOVUS_JS . '/build/app.js' ?>"></script> -->
<?php
get_footer();
