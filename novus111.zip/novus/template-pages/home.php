<?php

/**
 * Template Name: Home
 */
get_header();

get_template_part('template-parts/home/banner');
get_template_part('template-parts/home/intro');
get_template_part('template-parts/home/location');
get_template_part('template-parts/home/book');
get_template_part('template-parts/home/reservation');
get_template_part('template-parts/home/gallery');
get_template_part('template-parts/home/testimonials');
get_template_part('template-parts/home/event');

get_template_part('template-parts/feedback');

get_footer();
