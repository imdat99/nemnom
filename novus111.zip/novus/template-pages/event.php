<?php
/**
 * Template Name: Event
 */
get_header();

get_template_part( 'template-parts/banner' );
get_template_part( 'template-parts/event/event' );
get_template_part( 'template-parts/event/count-down' );
get_template_part( 'template-parts/home/reservation' );

get_footer();