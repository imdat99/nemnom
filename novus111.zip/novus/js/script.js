let Ichoice;
document.addEventListener("DOMContentLoaded", function () {
  const header = document.querySelector(".footer-menu");
  const $ = jQuery;

  const navControl = document.getElementById("nav-control");
  navControl.addEventListener("click", function () {
    header.classList.contains("nav-mobile")
      ? header.classList.remove("nav-mobile")
      : header.classList.add("nav-mobile");
  });

  // Accordion
  const accordion = document.querySelector(".accordions");
  if (accordion) {
    let acc = accordion.getElementsByClassName("control");
    let i;

    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function () {
        this.classList.toggle("active");

        const panel = this.nextElementSibling;
        panel.classList.toggle("active");
        if (panel.style.maxHeight) {
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + 60 + "px";
        }
      });
    }
  }

  if (document.querySelector(".home-gallery")) {
    new Splide(".home-gallery", {
      type: "loop",
      gap: "40px",
      perPage: 3,
      arrows: false,
      autoplay: true,
      breakpoints: {
        640: {
          perPage: 1,
        },
      },
    }).mount();
  }

  if (document.querySelector(".gallery-images")) {
    new Splide(".gallery-images", {
      type: "loop",
      gap: "40px",
      speed: 1500,
      perPage: 1,
      arrows: false,
      autoplay: true,
    }).mount();
  }

  if (document.querySelector(".home-testimonial")) {
    new Splide(".home-testimonial", {
      type: "loop",
      gap: "40px",
      perPage: 1,
      arrows: false,
      autoplay: true,
    }).mount();
  }

  if (document.querySelector(".home-event")) {
    new Splide(".home-event", {
      type: "loop",
      gap: "40px",
      perPage: 1,
      arrows: false,
      autoplay: true,
    }).mount();
  }

  // Tabs
  const tab = (links, panels) => {
    links.forEach((l) => {
      l.addEventListener("click", function () {
        links.forEach((el) => {
          el.classList.remove("active");
        });

        l.classList.add("active");

        panels.forEach((el) => {
          if (el.dataset.tab === l.dataset.tab) {
            el.classList.add("active");
          } else {
            el.classList.remove("active");
          }
        });
      });
    });
  };
  if (document.querySelector("select")) {
    const elements = document.querySelectorAll("select");
    elements.forEach((e) => {
      const choices = new Choices(e, {
        placeholder: true,
        placeholderValue: null,
      });
      choices.passedElement.element.addEventListener(
        "change",
        function (event) {
          if (event.target.name == "des_restaurant") {
            if (event.detail.value === "NOM NOM HOXTON") {
              $("#click-nomnom").click();
            } else {
              $("#click-nemnem").click();
            }
          }
          // do something creative here...
        },
        false
      );
      if (e.name == "des_restaurant") {
        Ichoice = choices;
      }
    });
  }
});
function restaurantSelect(name) {
  console.log(name, Ichoice);
  Ichoice.setChoiceByValue([name]);
  //   $ref = name;
  //   $ref(name);
}
