<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package novus
 */

?>

<?php
$contact_id = get_page_by_path('contact')->ID;

$email = rwmb_meta('email', null, $contact_id);
$phone = rwmb_meta('phone', null, $contact_id);
$address = rwmb_meta('address', null, $contact_id);
$facebook = rwmb_meta('facebook', null, $contact_id);
?>

<footer id="colophon" class="site-footer section-padding bg-red">
    <div class="container">
        <div class="row">
            <div class="col-4">
                <h5>NEM NEM ISLINGTON</h5>
                <p><b>Address</b>: 279 Upper street, London N1 2TZ</p>
                <p><b>Tel</b>: 020.7704.8770</p>
                <p><b>Email</b>: nemnem279@yahoo.com</p>
            </div>

            <div class="col-4">
                <h5>NOM NOM HOXTON</h5>
                <p><b>Address</b>: 134 F-G Kingsland Road, London E2 8DY</p>
                <p><b>Tel</b>: 020.7729.8344</p>
                <p><b>Email</b>: nomnom134@yahoo.com</p>
            </div>

            <div class="col-4">
                <h5>OPEN HOURS</h5>
                <p>Mon-Thurs: 12:00 - 15:00 <br>
                    17:00 - 10.30</p>
                <p>Fri: 12:00 - 15:00 <br>
                    17:00 - 11:00</p>
                <p>Sat: 12:00 - 11:00</p>
                <p>Sun: 12:00 - 10.30</p>
            </div>
        </div>
    </div>

    <?php get_template_part('template-parts/contact-info')  ?>
</footer>


<section class="footer-menu">
    <div class="container">
        <?php wp_nav_menu('menu_1'); ?>

        <button id="nav-control">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</section>
</main>

<?php wp_footer(); ?>

</body>

</html>