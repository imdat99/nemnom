<?php
// $galleries = rwmb_meta('gallery_images', ['size' => 'thumb-500']);
// var_dump($galleries);
$data = create_data_ig();
$chunks = array_chunk($data, 6);
// print_r($galleries);
?>
<section class="gallery bg-red section-padding">
    <div class="container">
        <div class="splide gallery-images">
            <div class="splide__track">
                <div class="splide__list">
                    <?php foreach ($chunks as $g) : ?>
                        <div class="splide__slide">
                            <?php foreach ($g as $item) :
                                $img_url = $item->media_type === "VIDEO" ? $item->thumbnail_url : $item->media_url;
                            ?>
                                <div class="splide__slide-item" style="background-image: url('<?= $img_url; ?>'); background-size: cover; background-position: center center; background-repeat: no-repeat; opacity: 1;">
                                    <span style="width:300px; height:300px; display: block"></span>
                                    <img alt="<?= $item->caption ?>" decoding="async" style="display: none;" />
                                </div>
                                <!-- <img src="<?= $img_url; ?>"> -->
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>