<?php
$banner = rwmb_meta( 'banner_image', ['size' => 'full'] );
?>

<section class="page-banner">
	<img src="<?= $banner['full_url'] ?>">

	<h1 class="title"><?php the_title() ?></h1>
</section>