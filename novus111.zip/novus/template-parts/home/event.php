<?php
$images = rwmb_meta('event_images', ['size' => 'full']);
$des    = rwmb_meta('event_description');
$content = rwmb_meta('event_content');
?>

<section class="event section-padding" style="background:url(<?= $bg['full_url'] ?>) center / cover no-repeat">
    <div class="container">
        <h2 class="title">Events</h2>

        <p class="event__description"><?= $des ?></p>

        <div class="row jcsb">
            <img class="event__background" src="<?= NOVUS_IMG . '/event-detail.png' ?>">

            <div class="col-5">
                <div class="splide home-event">
                    <div class="splide__track">
                        <div class="splide__list">
                            <?php foreach ($images as $img) : ?>
                                <div class="splide__slide">
                                    <img src="<?= $img['url']; ?>">
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-5 event__content">
                <?= $content ?>

                <a href="<?= get_permalink(get_page_by_path('events')) ?>">[See more]</a>
            </div>
        </div>
    </div>
</section>