<?php
$images = rwmb_meta( 'gallery', ['size' => 'thumb-300'] );
?>

<section class="gallery bg-red section-padding">
	<div class="container">
		<h2 class="title">Gallery</h2>

		<div class="row jcc">
			<div class="col-10">
				<div class="splide home-gallery">
					<div class="splide__track">
						<div class="splide__list">
							<?php foreach ( $images as $img ) : ?>
								<div class="splide__slide">
									<img src="<?= $img['url']; ?>">
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<a href="<?= get_permalink( get_page_by_path( 'gallery' ) ) ?>">[ See more ]</a>
	</div>
</section>