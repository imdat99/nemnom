<section class="home-reservation section-padding" style="position:relative">
    <img class="event__background" src="https://www.nemnoms.co.uk/wp-content/themes/novus/images/event-detail.png" style="border: none;
				width: 30%;
				margin: 0;
				transform: none;
				height: auto;
				border-radius: 0;
				top: 30%;
				right: 0;
				left: auto;
				z-index: -1;">
    <div class="container">
        <h2 class="title">BOOK A TABLE</h2>

        <p class="ttu txt-center">choose a restaurant</p>

        <div class="restaurant-wrapper" x-data="{tab: 'nemnem'}">
            <div class="row d-none">
                <div class="col-6">
                    <h4 role="button" id="click-nemnem" :class="{'active': tab === 'nemnem'}" @click="() => {tab = 'nemnem'; restaurantSelect('NEM NEM ISLINGTON')}">
                        NEM NEM ISLINGTON
                    </h4>


                </div>

                <div class="col-6">
                    <h4 role="button" id="click-nomnom" :class="{'active': tab === 'nomnom'}" @click="() => {tab = 'nomnom'; restaurantSelect('NOM NOM HOXTON')}">
                        NOM NOM HOXTON
                    </h4>
                </div>
            </div>

            <div x-show="tab !== 'confirm'">

                <?= do_shortcode('[contact-form-7 id="c9d0cb3" title="NomNom_copy"]') ?>
            </div>
            <!-- <iframe width="600" height="350" id="gmap_canvas" src="https://maps.google.com/maps?q=279%20Upper%20street,%20London%20N1%202TZ&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe> -->

            <div x-show="tab === 'confirm'">
                <h3 class="txt-center">
                    Your reservation has been confirmed.
                </h3>
                <p class="txt-center">
                    We are looking forward to serving you soon!
                </p>
            </div>
        </div>
    </div>
</section>