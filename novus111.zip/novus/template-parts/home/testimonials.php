<?php
$id = get_option( 'page_on_front' );
$tess = rwmb_meta( 'testimonials', null, $id );
$bg = rwmb_meta( 'tes_background', ['size' => 'full'], $id );
?>

<section class="testimonials section-padding"
		style="background:url(<?= $bg['full_url'] ?>) center / cover no-repeat">
	<div class="container">
		<h2 class="title">Testimonials</h2>

		<small>What Clients Say</small>
		<img src="<?= NOVUS_IMG . '/star.svg' ?>">

		<div class="row jcc">
			<div class="col-10">
				<div class="splide home-testimonial">
					<div class="splide__track">
						<div class="splide__list">
							<?php foreach ( $tess as $t ) : ?>

								<div class="splide__slide">
									<a class="item" href="<?= $t['url'] ?>" target="_blank">
										<p><?= $t['text'] ?></p>
										<b><?= $t['name'] ?></b>
									</a>
								</div>

							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>