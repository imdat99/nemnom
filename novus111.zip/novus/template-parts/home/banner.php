<?php
$page_id = get_queried_object_id();
$banner = rwmb_meta( 'banner_image', ['size' => 'full'] );

?>

<section class="banner"
	data-img="<?= $banner['full_url'] ?>"
	data-noise="<?= NOVUS_IMG . '/noise.png' ?>"
	data-map="<?= NOVUS_IMG . '/cooking-maps.jpg' ?>"
	>
	<div class="Background">
		<canvas class="Background-canvas"></canvas>
	</div>

	<div class="container banner__content dflex flex-column aic jcc" style="position:inherit;z-index:9">
		<?= get_custom_logo() ?>

		<div class="banner__content-actions dflex aic">
			<a href="<?= get_permalink( get_page_by_title( 'reservation' ) ) ?>" class="btn">
				<span>Make reservation</span>
			</a>

<!-- 			<a href="#booking" class="btn">
				<span>Order now</span>
			</a> -->
		</div>
	</div>
</section>