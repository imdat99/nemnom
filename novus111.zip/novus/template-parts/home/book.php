<?php
$restaurants = rwmb_meta('restaurants');

?>

<section id="booking" class="booking bg-red section-padding" style="position: relative">
    <img class="event__background" src="https://www.nemnoms.co.uk/wp-content/themes/novus/images/event-detail.png" style="    border: none;
    width: 30%;
    margin: 0;
    transform: none;
    height: auto;
    border-radius: 0;
    top: 20%;
    z-index: -1;">
    <div class="container">
        <h2 class="title">OUR MENU</h2>
        <div class="menu-container">
            <ul class="nemu-list">
                <?php foreach ($restaurants as $res) : ?>
                    <li class="nemu-list__item">
                        <a target="_blank" href="<?= $res['button_id'] ?>">
                            <h4 class="h4"><?= $res['name'] ?></h2>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- <div class="row">
			<?php foreach ($restaurants as $res) : ?>
				<div class="col-4">
					<h2 class="h3"><?= $res['name'] ?></h2>

					<a class="btn" target="_blank" href="<?= $res['button_id'] ?>">
						<span>See MENU</span>
					</a>

					<div class="image">
						<?= wp_get_attachment_image($res['image'], 'full') ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div> -->
    </div>
</section>
<script src="https://www.fbgcdn.com/embedder/js/ewm2.js" defer async></script>