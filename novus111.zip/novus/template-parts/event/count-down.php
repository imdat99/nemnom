<?php
$background = rwmb_meta( 'event_background', ['size' => 'full'] );
$time       = rwmb_meta( 'event_date' );
$content    = rwmb_meta( 'event_detail' );

if ( $time ) :
?>

<section class="page-event section-padding"
	style="background:url(<?= $background['url'] ?>) center / cover no-repeat">
	<div class="container">
		<h2 class="title">Comming soon</h2>

		<div class="row jcc">
			<div class="col-12" id="time"></div>

			<div class="col-10">
				<?= $content ?>
			</div>
		</div>
	</div>
</section>

<script>
var countDownDate = new Date('<?= $time ?>').getTime();

var x = setInterval(function() {
	var now = new Date().getTime();
	var distance = countDownDate - now;

	var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	var seconds = Math.floor((distance % (1000 * 60)) / 1000);

	document.getElementById("time")
		.innerHTML = `<div><span>${days}</span>Days</div>
					<div><span>${hours}</span>Hours</div>
					<div><span>${minutes}</span>Minutes</div>
					<div><span>${seconds}</span>Seconds</div>
					`;

	if (distance < 0) {
		clearInterval(x);
		document.getElementById("time").innerHTML = "EXPIRED";
	}
}, 1000);
</script>

<?php endif; ?>