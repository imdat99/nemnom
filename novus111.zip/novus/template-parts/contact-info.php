<div class="container contact">
	<h2 class="title">Contact us</h2>

	<?php get_template_part( 'template-parts/social' ) ?>

	<p>&copy;2022 Copyright by Nem.Nom Restaurant. All Rights Reserved</p>
</div>