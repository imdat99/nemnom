<section class="feedback section-padding" style="position: relative">
	<img class="event__background" src="https://www.nemnoms.co.uk/wp-content/themes/novus/images/event-detail.png"
		 style="border: none;
				width: 30%;
				margin: 0;
				transform: none;
				height: auto;
				border-radius: 0;
				top: 0;
				z-index: -1;">
	<div class="container">
		<h2 class="title">Feedback</h2>

		<div class="row jcc">
			<div class="col-8">
				<?= do_shortcode( '[contact-form-7 id="5" title="Feedback"]' ) ?>
			</div>
		</div>
	</div>
</section>