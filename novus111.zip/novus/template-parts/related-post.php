<article>
	<a href="<?php the_permalink() ?>" class="thumbnail">
		<?php the_post_thumbnail( 'thumb-250' ) ?>
	</a>

	<a href="<?php the_permalink() ?>">
		<h2 class="c-blue h5"><?php the_title(); ?></h2>
	</a>
</article>