<?php
$nemnem = new WP_Query([
    'post_type'      => 'post',
    'posts_per_page' => -1,
    'category_name'  => 'nemnem,'
]);

$nomnom = new WP_Query([
    'post_type'      => 'post',
    'posts_per_page' => -1,
    'category_name'  => 'nomnom'
]);

$nemnem_id = 'https://www.nemnoms.co.uk/nemnem-menu/';
$nomnom_id = 'https://www.nemnoms.co.uk/nomnom-menu/';
?>

<section class="page-menu section-padding">
    <div class="container">
        <p class="ttu txt-center">choose a restaurant</p>

        <div class="restaurant-wrapper" x-data="{tab: 'nemnemmenu'}">
            <div class="row">
                <div class="col-6">
                    <h4 role="button" :class="{'active': tab === 'nemnemmenu'}" @click="tab='nemnemmenu'">
                        NEM NEM ISLINGTON
                    </h4>
                </div>

                <div class="col-6">
                    <h4 role="button" :class="{'active': tab === 'nomnommenu'}" @click="tab='nomnommenu'">
                        NOM NOM HOXTON
                    </h4>
                </div>
            </div>

            <div class="col-12 dishes" x-show="tab === 'nemnemmenu'">
                <?php
                while ($nemnem->have_posts()) :
                    $nemnem->the_post();
                    get_template_part('template-parts/content-post');
                endwhile; ?>
            </div>


            <div class="col-12 dishes" x-show="tab === 'nomnommenu'">
                <?php
                while ($nomnom->have_posts()) :
                    $nomnom->the_post();
                    get_template_part('template-parts/content-post');
                endwhile; ?>
            </div>

            <div class="col-12 dishes__action">
                <a class="btn" x-show="tab === 'nemnemmenu'" target="_blank" href="<?= $nemnem_id ?>">
                    <span>See more</span>
                </a>

                <a class="btn" x-show="tab === 'nomnommenu'" target="_blank" href="<?= $nomnom_id ?>">
                    <span>See more</span>
                </a>
            </div>
        </div>
    </div>
</section>

<script src="https://www.fbgcdn.com/embedder/js/ewm2.js" defer async></script>