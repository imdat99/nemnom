<?php
$videos = rwmb_meta('video');
$text = rwmb_meta('intro_text');

$img1 = rwmb_meta('image_1', ['size' => 'full']);
$img2 = rwmb_meta('image_2', ['size' => 'full']);
$text2 = rwmb_meta('text_wall');
?>

<section class="intro section-padding">
    <div class="container">
        <h2 class="title">Welcome to</h2>

        <h3 class="h1 txt-center">NEM.NOM RESTAURANT</h3>

        <div class="row jcsb intro__top">
            <div class="col-3 dflex jcc">
                <img src="<?= $img1['url'] ?>">
            </div>

            <div class="col-4">
                <?= $text2 ?>
            </div>

            <div class="col-3 dflex jcc">
                <img src="<?= $img2['url'] ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-8">
                <?php foreach ($videos as $video) : ?>
                    <div class="intro__video">
                        <video autoplay playsinline loop muted src="<?= $video['src']; ?>">
                            <source src="<?= $video['src']; ?>" type="<?= $video['type'] ?>">
                        </video>
                    </div>
                <?php endforeach ?>
            </div>

            <div class="col-4 intro__text">
                <p><?= $text ?></p>
            </div>
        </div>
    </div>
</section>