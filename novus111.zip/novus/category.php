<?php
$term = get_queried_object();
get_header();
?>
<img src="<?= NOVUS_IMG . '/page-banner.jpg' ?>" class="page-banner">

<section class="blog-posts">
	<div class="container">
		<h2 class="h1 txt-center c-blue"><?= $term->name ?></h2>

		<?php
		if ( have_posts() ) :
			$i = 0;
		?>
		<div class="row">
			<?php
			while ( have_posts() ) : 
				$i++;
				the_post(  );
			?>

				<div class="col-4">
					<article>
						<a href="<?php the_permalink( ) ?>" class="thumbnail">
							<?php the_post_thumbnail( 'thumb-250' ) ?>
						</a>

						<a href="<?php the_permalink( ) ?>">
							<h4 class="c-blue"><?php the_title() ?></h4>
						</a>
						<?php the_excerpt(  ) ?>
					</article>
				</div>

			<?php endwhile; ?>

			<div class="col-12">
				<?php the_posts_pagination( [
					'screen_reader_text' => ' ',
					'prev_text'          => __( '', 'novus' ),
					'next_text'          => __( '', 'novus' ),
				] ); ?>
			</div>
		</div>
		<?php endif; ?>
	</div>
</section>



<?php
get_footer();
