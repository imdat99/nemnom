<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package novus
 */

get_header();
?>

<section class="single-post-content">
	<div class="container">
		<div class="row">
			<div class="col-8">
				<h1 class="c-blue h3"><?php the_title(); ?></h1>

				<div class="entry-info">
					<span><?= get_the_date() ?></span>

					<ul class="social-share">
						<li>Share</li>
						<li>
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?= get_permalink(  ) ?>&amp;display=popup">
								<img src="<?= NOVUS_IMG . '/svg/facebook.svg' ?>" alt="facebook" loading="lazy">
							</a>
						</li>

						<li>
							<a href="http://twitter.com/share?text=I%20found%20something%20quite%20hot%20over%20here&amp;url=<?= get_permalink(  ) ?>&amp;hashtags=titoay">
								<img src="<?= NOVUS_IMG . '/svg/twitter.svg' ?>" alt="twitter" loading="lazy">
							</a>
						</li>

						<li>
							<a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= get_permalink(  ) ?>">
								<img src="<?= NOVUS_IMG . '/svg/linkedin.svg' ?>" alt="linkedin" loading="lazy">
							</a>
						</li>

						<li>
							<a href="mailto:?subject=I%20wanted%20you%20to%20see%20this%20site&amp;body=Check%20out%20this%20site%20<?= get_permalink(  ) ?>." title="Share by Email">
								<img src="<?= NOVUS_IMG . '/svg/mail.svg' ?>" alt="mail" loading="lazy">
							</a>
						</li>
					</ul>
				</div>

				<?php the_post_thumbnail( 'full' ) ?>

				<?php the_content(); ?>
			</div>

			<div class="col-3 related-post">
				<h2 class="h4 c-blue">Bài viết liên quan</h2>
				<?php
					$posts = new WP_Query( [
						'post_type' => 'post',
						'posts_per_page' => 3,
						'orderby' => 'rand',
					] );

					while ( $posts->have_posts() ) :
						$posts->the_post();
							get_template_part( 'template-parts/related-post' );
					endwhile;
				?>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
